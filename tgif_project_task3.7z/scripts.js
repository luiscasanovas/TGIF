const parties = {
  D: "Democrat",
  R: "Republican",
  I: "Independent"
};

const headers = [
  "Name",
  "Party",
  "State",
  "Years in Office",
  "% Votes with Party"
];

const table = document.getElementById("membersTable");
let senatorsData = [];
let selectedState = "";

function makeStatesMenu(statesData) {
  const stateDropdown = document.getElementById("stateDropdown");
  stateDropdown.innerHTML = "";

  const defaultOption = document.createElement("option");
  defaultOption.value = "";
  defaultOption.textContent = "Select a state";
  stateDropdown.appendChild(defaultOption);

  for (const [abbr, name] of Object.entries(statesData)) {
    const hasSenators = senatorsData.some((member) => member.state === abbr);
    if (hasSenators) {
      const option = document.createElement("option");
      option.value = abbr;
      option.textContent = name;
      stateDropdown.appendChild(option);
    }
  }

  if (selectedState) {
    stateDropdown.value = selectedState;
  }
}

function makeTableHeader() {
  table.innerHTML = "";
  const headerRow = table.insertRow(0);
  headers.forEach((header) => {
    const th = document.createElement("th");
    th.innerHTML = header;
    headerRow.appendChild(th);
  });
}

function makeMembersRows(filteredMembers) {
  filteredMembers.forEach((member) => {
    const row = table.insertRow();
    const memberUrl = member.url;
    const memberName = `${member.first_name} ${member.last_name}`;
    const linkMembers = memberUrl ? `<a href="${memberUrl}" target="_blank">${memberName}</a>` : memberName;

    const cell = row.insertCell();
    cell.innerHTML = linkMembers;

    const partyCell = row.insertCell();
    partyCell.innerHTML = parties[member.party];

    const stateCell = row.insertCell();
    stateCell.innerHTML = member.state;

    const seniorityCell = row.insertCell();
    seniorityCell.innerHTML = member.seniority;

    const votesCell = row.insertCell();
    votesCell.innerHTML = member.votes_with_party_pct ? `${member.votes_with_party_pct}%` : "N/A";
  });
}

const filterSenatorsByPartyAndState = () => {
  const checkedParties = Array.from(
    document.querySelectorAll("input[type=checkbox]:checked")
  ).map((checkbox) => checkbox.value);

  const selectedState = document.getElementById("stateDropdown").value;

  const filteredMembers = senatorsData.filter((member) => {
    const partyFilter = checkedParties.includes(member.party);

    const stateFilter = selectedState === "" || member.state === selectedState;

    return partyFilter && stateFilter;
  });

  return filteredMembers;
};

function filterTable() {
  const filteredMembers = filterSenatorsByPartyAndState();
  makeTableHeader();
  makeMembersRows(filteredMembers);
}

function fetchStatesAndCreateDropdown() {
  fetch(
    "https://gist.githubusercontent.com/mshafrir/2646763/raw/8b0dbb93521f5d6889502305335104218454c2bf/states_hash.json"
  )
    .then((response) => {
      if (!response.ok) {
        throw new Error("Could not fetch states data");
      }
      return response.json();
    })
    .then((statesData) => {
      makeStatesMenu(statesData);
      filterTable(); 
    })
    .catch((error) => {
      console.error("Fetch states data error:", error);
    });
}

function fetchCongressData(chamber) {
  let url;

  if (chamber === "house") {
    url = "https://api.propublica.org/congress/v1/117/house/members.json";
  } else {
    url = "https://api.propublica.org/congress/v1/117/senate/members.json";
  }

  return fetch(url, {
    headers: {
      "X-API-Key": "9IkyH0aHLxluBFhFFPrGpTGlDuNGdKBFOSdJC04Y"
    }
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`Could not fetch ${chamber} data`);
      }
      return response.json();
    })
    .then((data) => {
      if (data && data.results && data.results[0].members) {
        senatorsData = data.results[0].members;
        fetchStatesAndCreateDropdown(); 
      } else {
        throw new Error(`Invalid JSON structure for ${chamber} data`);
      }
    })
    .catch((error) => console.error(error));
}

function setPageContent(chamber) {
  const pageContentElement = document.getElementById("pageContent");
  if (!pageContentElement) {
    console.error("Page content element not found.");
    return;
  }

  if (chamber === "senate") {
    pageContentElement.innerHTML = `
      <h1>Senators</h1>
      <p id="senateParagraph">First convened in 1789, the composition and powers of the Senate are established in Article One of the U.S. Constitution. Each state is represented by two senators, regardless of population, who serve staggered six-year terms. The Senate has several exclusive powers not granted to the House, including consenting to treaties as a precondition to their ratification and consenting to or confirming appointments of Cabinet secretaries, federal judges, other federal executive officials, military officers, regulatory officials, ambassadors, and other federal uniformed officers, as well as trial of federal officials impeached by the House.</p>`;
  } else if (chamber === "house") {
    pageContentElement.innerHTML = `
      <h1>Representatives</h1>
      <p id="houseParagraph">The major power of the House is to pass federal legislation that affects the entire country, although its bills must also be passed by the Senate and further agreed to by the U.S. President before becoming law (unless both the House and Senate re-pass the legislation with a two-thirds majority in each chamber). The House has some exclusive powers: the power to initiate revenue bills, to impeach officials (impeached officials are subsequently tried in the Senate), and to elect the U.S. President in case there is no majority in the Electoral College.</p>
      <p>Each U.S. state is represented in the House in proportion to its population as measured in the census, but every state is entitled to at least one representative.</p>`;
  } else {
    console.error("Invalid chamber specified.");
  }
}

function start() {
  const chamber = getChamberParameter();
  const chamberTitleElement = document.getElementById("chamberTitle");
  if (chamberTitleElement) {
    chamberTitleElement.textContent = chamber === "house" ? "House Members" : "Senate Members";
  }
  fetchCongressData(chamber)
    .then(() => {
      setPageContent(chamber); 
    })
    .catch((error) => console.error(error));
}
function getChamberParameter() {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get("chamber") || "senate"; 
}

start();

function getUrlParameter(name) {
  name = name.replace(/[\[\]]/g, "\\$&");
  const regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)");
  const results = regex.exec(window.location.href);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}




document.querySelectorAll("input[type=checkbox]").forEach((checkbox) => {
  checkbox.addEventListener("change", filterTable);
});

document.getElementById("stateDropdown").addEventListener("change", filterTable);

document.addEventListener("DOMContentLoaded", function() {
  const currentPageUrl = window.location.href;
  
  const navLinks = document.querySelectorAll(".navbar-nav a");
  navLinks.forEach(link => {
    if (link.href === currentPageUrl) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });

  const dropdownTitle = document.querySelector(".dropdown-toggle");
  const dropdownItems = document.querySelectorAll(".dropdown-menu a");
  const isChamberPage = currentPageUrl.includes("members.html");
  if (isChamberPage) {
    dropdownTitle.classList.add("active");
    dropdownItems.forEach(item => {
      if (item.href === currentPageUrl) {
        item.classList.add("active");
      } else {
        item.classList.remove("active");
      }
    });
  } else {
    dropdownTitle.classList.remove("active");
    dropdownItems.forEach(item => item.classList.remove("active"));
  }
});