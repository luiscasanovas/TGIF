const parties = {
  D: 'Democrat',
  R: 'Republican',
  I: 'Independent'
};

let senatorsData = [];
let selectedState = '';

// Fetch and process data
function fetchAndProcessData() {
  // States dropdown menu
  function makeStatesMenu(statesData) {
    const stateDropdown = document.getElementById('stateDropdown');
    stateDropdown.innerHTML = '';

    // Dropdown list
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Select a state';
    stateDropdown.appendChild(defaultOption);

    // Only states with Senators
    for (const [abbr, name] of Object.entries(statesData)) {
      const hasSenators = senatorsData.some(member => member.state === abbr);
      if (hasSenators) {
        const option = document.createElement('option');
        option.value = abbr;
        option.textContent = name;
        stateDropdown.appendChild(option);
      }
    }

    
    if (selectedState) {
      stateDropdown.value = selectedState;
    }
  }

  // Fetch states data
  function fetchStates() {
    fetch("https://gist.githubusercontent.com/mshafrir/2646763/raw/8b0dbb93521f5d6889502305335104218454c2bf/states_hash.json")
      .then(response => {
        if (!response.ok) {
          throw new Error('Could not fetch states data');
        }
        return response.json();
      })
      .then(statesData => {
        // Fetch senators data
        fetch("https://api.propublica.org/congress/v1/117/senate/members.json", {
          headers: {
            'X-API-Key': '9IkyH0aHLxluBFhFFPrGpTGlDuNGdKBFOSdJC04Y'
          }
        })
          .then(response => {
            if (!response.ok) {
              throw new Error('Could not fetch senators data');
            }
            return response.json();
          })
          .then(data => {
            if (data && data.results && data.results.length > 0) {
              senatorsData = data.results[0].members || [];
              makeStatesMenu(statesData);
            } else {
              console.error('Invalid JSON structure');
            }
          })
          .catch(error => console.error(error));
      })
      .catch(error => {
        console.error('Fetch states data error:', error);
      });
  }

  fetchStates();

  // Fetch senators data based on party and state filter
  fetch("https://api.propublica.org/congress/v1/117/senate/members.json", {
          headers: {
            'X-API-Key': '9IkyH0aHLxluBFhFFPrGpTGlDuNGdKBFOSdJC04Y'
          }
        })
    .then(response => {
      if (!response.ok) {
        throw new Error('Could not fetch senators data');
      }
      return response.json();
    })
    .then(data => {
      if (data && data.results && data.results.length > 0) {
        senatorsData = data.results[0].members || [];

        // Filter senators by party and state
        const checkedParties = Array.from(document.querySelectorAll('input[type=checkbox]:checked'))
          .map(checkbox => checkbox.value);
        selectedState = document.getElementById('stateDropdown').value;
        const filteredMembers = senatorsData.filter(member =>
          checkedParties.includes(member.party) && (selectedState === '' || member.state === selectedState)
        );

        // Populate table with filtered senators
        const table = document.getElementById('membersTable');
        table.innerHTML = '';
        const headers = ['Name', 'Party', 'State', 'Years in Office', '% Votes with Party'];
        const headerRow = table.insertRow(0);
        // Iteration and creation of the table
        headers.forEach(header => {
          const th = document.createElement('th');
          th.innerHTML = header;
          headerRow.appendChild(th);
        });

        filteredMembers.forEach(member => {
          const row = table.insertRow();
          const memberUrl = member.url;
          const memberName = `${member.first_name} ${member.last_name}`;
          const linkMembers = `<a href="${memberUrl}" target="_blank">${memberName}</a>`;

          const cell = row.insertCell();
          cell.innerHTML = linkMembers;

          const partyCell = row.insertCell();
          partyCell.innerHTML = parties[member.party];

          const stateCell = row.insertCell();
          stateCell.innerHTML = member.state;

          const seniorityCell = row.insertCell();
          seniorityCell.innerHTML = member.seniority;

          const votesCell = row.insertCell();
          votesCell.innerHTML = member.votes_with_party_pct;
        });
      } else {
        console.error('Invalid JSON structure');
      }
    })
    .catch(error => console.error(error));
}

fetchAndProcessData();
document.getElementById('checkParties').addEventListener('change', fetchAndProcessData);
document.getElementById('stateDropdown').addEventListener('change', fetchAndProcessData);